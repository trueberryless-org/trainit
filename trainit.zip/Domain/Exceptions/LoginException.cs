﻿namespace Domain.Exceptions;

public class LoginException : Exception {
}
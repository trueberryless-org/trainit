﻿namespace Domain.Exceptions;

public class DuplicateEmailException : Exception {
}    
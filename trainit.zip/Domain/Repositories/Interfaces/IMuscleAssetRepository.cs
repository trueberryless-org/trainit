﻿using Model.Entities.Assets;

namespace Domain.Repositories.Interfaces;

public interface IMuscleAssetRepository : IRepository<MuscleAsset>
{
    
}
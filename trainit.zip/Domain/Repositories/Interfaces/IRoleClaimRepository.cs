﻿using Model.Entities.Authentication;

namespace Domain.Repositories.Interfaces;

public interface IRoleClaimRepository : IRepository<RoleClaim> {
}
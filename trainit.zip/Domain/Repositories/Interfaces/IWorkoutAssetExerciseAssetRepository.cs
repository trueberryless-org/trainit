﻿using Model.Entities.Assets;

namespace Domain.Repositories.Interfaces;

public interface IWorkoutAssetExerciseAssetRepository : IRepository<WorkoutAssetExerciseAsset>
{
    
}
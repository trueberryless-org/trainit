﻿using Model.Entities.per_User;

namespace Domain.Repositories.Interfaces;

public interface IWorkoutExerciseRepository : IRepository<WorkoutExercise>
{
    
}
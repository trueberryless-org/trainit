﻿using Model.Entities.Assets;

namespace Domain.Repositories.Interfaces;

public interface IMachineAssetRepository : IRepository<MachineAsset>
{
    
}
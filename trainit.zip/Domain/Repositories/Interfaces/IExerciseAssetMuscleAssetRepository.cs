﻿using Model.Entities.Assets;

namespace Domain.Repositories.Interfaces;

public interface IExerciseAssetMuscleAssetRepository : IRepository<ExerciseAssetMuscleAsset>
{
    
}
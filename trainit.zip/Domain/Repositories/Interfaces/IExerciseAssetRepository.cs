﻿using Model.Entities.Assets;

namespace Domain.Repositories.Interfaces;

public interface IExerciseAssetRepository : IRepository<ExerciseAsset>
{
    
}
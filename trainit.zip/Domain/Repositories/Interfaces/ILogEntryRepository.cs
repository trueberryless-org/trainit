﻿using Model.Entities.Log;

namespace Domain.Repositories.Interfaces;

public interface ILogEntryRepository : IRepository<LogEntry>
{
    
}
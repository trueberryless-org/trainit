﻿using Model.Entities.Authentication;

namespace Domain.Repositories.Interfaces;

public interface IRoleRepository : IRepository<Role> {
}
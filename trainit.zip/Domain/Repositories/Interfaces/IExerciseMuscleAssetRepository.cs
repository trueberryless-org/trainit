﻿using Model.Entities.per_User;

namespace Domain.Repositories.Interfaces;

public interface IExerciseMuscleAssetRepository : IRepository<ExerciseMuscleAsset>
{
    
}
﻿using Model.Entities.Assets;

namespace Domain.Repositories.Interfaces;

public interface IWorkoutAssetRepository : IRepository<WorkoutAsset>
{
    
}
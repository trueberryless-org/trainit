﻿namespace Model.Entities.Log;

public enum ELogEntryType
{
    USERNAME, 
    EMAIL,
    PASSWORD
}